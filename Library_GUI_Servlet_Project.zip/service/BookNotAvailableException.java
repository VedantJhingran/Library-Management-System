package service;
public class BookNotAvailableException extends LibraryException {
    public BookNotAvailableException(String msg) { super(msg); }
}
